import React, {Component} from 'react';
import {InputGroup, InputGroupAddon, Input} from 'reactstrap';


class Search extends Component {
  constructor() {
    super();
    this.state = {term: ''};
  }

  onChange(event) {
    this.setState({term: event.target.value});
    this.props.onChange({...event});
  }

  render() {
    return (
      <div>
        <InputGroup>
          <Input onChange={this.onChange.bind(this)} value={this.state.term} placeholder="Search for..."/>
          <InputGroupAddon addonType="append">Search</InputGroupAddon>
        </InputGroup>
      </div>
    )
  }
}

export default Search;