import _ from 'lodash';

class RecipePuppy {

  search(term) {
    //we use JSONP since the api has no CORS...
    //This is probably a security risk - so in production we will should a server side proxy.
    let scriptObj = document.createElement('script');
    const promise = new Promise((resolve, reject) => {
      window.recipePuppyCB = (data) => {
        resolve(data);
        _.defer(() => {
          // document.head.removeChild(scriptObj);
        });
      };
      scriptObj.src = 'http://www.recipepuppy.com/api?q=' + encodeURI(term) + '&callback=recipePuppyCB&random=' + Math.random();
      document.head.appendChild(scriptObj);
    });
    return promise;
  }
}

export default RecipePuppy;

