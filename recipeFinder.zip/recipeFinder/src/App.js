import React, {Component} from 'react';
import {Navbar, NavbarBrand, Nav, NavItem, Container} from 'reactstrap';
import _ from 'lodash';

import Search from './Search';
import Results from './Results';
import RecipePuppyApi from './api/RecipePuppy';

class App extends Component {
  constructor() {
    super();
    this.api = new RecipePuppyApi();
    this.state = {recipes: [], searchTerm: ''};
    this._searchRecipeDebounced = _.debounce(this.searchRecipeNow, 500);
  }

  componentWillMount() {

  }

  searchRecipeNow(term) {
    this.api.search(term).then((response) => {
      if (_.isEmpty(term)) {
        this.setState({recipes: []});
      } else if (_.has(response, 'results')) {
        this.setState({recipes: response.results});
      } else {
        this.setState({recipes: []});
      }
    })
  }

  onSearchChange(event) {
    const term = event.target.value;
    this._searchRecipeDebounced(term);
  }

  render() {
    return (
      <div>
        <Navbar>
          <NavbarBrand>
            Recipe finder
          </NavbarBrand>
          <Nav className='float-left'>
            <NavItem>
              Home
            </NavItem>
          </Nav>
        </Navbar>
        <Container>
          <Search onChange={this.onSearchChange.bind(this)}/>
          <div className={"results"}>
            <Results data={this.state.recipes}/>
          </div>
        </Container>
      </div>
    );
  }
}

export default App;
