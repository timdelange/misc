import React, {Component} from 'react';
import {Table} from 'reactstrap';
import _ from 'lodash';

class Results extends Component {
  renderItems() {
    if (_.isArray(this.props.data)) {
      return this.props.data.map((value, index) => {

        return (
          <tr key={index}>
            <td>
              <a href={value.href}>{value.title}</a>
            </td>
          </tr>
        )
      })
    }
  }

  render() {
    return (
      <Table striped>
        <tbody>
        {this.renderItems()}
        </tbody>
      </Table>
    )
  }
}

export default Results;